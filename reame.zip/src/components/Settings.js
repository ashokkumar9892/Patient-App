import React from "react";

const Settings = (props) => {
  return <div>Settings</div>;
};

export { Settings };
